# Stillwake Studio — independent audit addendum

**Audit date:** 2026-11-09  
**Classification:** hardened prototype / production candidate; **not production-certified**  
**Scope:** source tree and release ZIP review. No production credentials, deployed database, or live xAI environment were available.

## Executive correction

The prior handoff used language that was too confident. “Engineer-grade” described the intent of the hardening work, not a verified release state. The project has meaningful server-side controls, but local unit tests do not prove route behavior under deployment, database concurrency, upstream billing, or browser compatibility.

The prior ZIP also included an app-builder screenshot showing the older one-checkbox demo. That image did not match the current `src/components/stillwake/studio.tsx`; it has been removed from this audited package rather than presented as current UI evidence.

## What the code actually contains

- Server-side xAI video generation and polling routes.
- Signed, expiring anonymous visitor cookies; visitor-bound HMAC job tokens.
- AES-256-GCM prompt encryption using a key derived from `STILLWAKE_SESSION_SECRET`.
- MIME-signature and dimension checks for JPEG, PNG, and WebP data URLs.
- PostgreSQL job ledger and transactional spend/clip reservations.
- Private xAI Files API output (30-day expiry) and a visitor-owned streaming download proxy.
- Shared PostgreSQL token-bucket admission controls for polling and downloads, plus bounded video streaming and single-range validation.
- Per-visitor quotas, trusted-Vercel-IP quotas, and shared PostgreSQL token buckets for polling and downloads.
- Local idempotency keys and request fingerprints to prevent duplicate local job creation on client retries.
- UI code for upload, framing, duration/resolution/audio settings, cost approval, video playback, and recent job history.

These are real implementations in the source. They are not equivalent to a completed security review or a successful live deployment.

## Verification actually performed in this workspace

| Check | Observed result | What it proves |
|---|---:|---|
| `node --test 'scripts/**/*.test.mjs'` | 198 passed, 0 failed | Repository script/tooling tests only; most are not video workflow tests. |
| Focused Imagine tests (limits, visitor/session, image validation, request fingerprint, token bucket, media streaming, idle-timeout behavior) | 26 passed, 0 failed | These are isolated utility/security/media tests under Node's type stripping, not end-to-end route tests. |
| `npm test` | Non-zero exit | The repository-script phase passed 198/198. In the broader Node test phase, 35 tests passed and 2 files failed to load because `@tanstack/react-start` and `jose` are absent. |
| ZIP integrity (`unzip -t`) | Passed | Archive structure/CRC is readable; it does not validate the app. |
| `npm ci`, typecheck, lint, Vite production build | Not run successfully | No dependency installation was available in this workspace. |
| Real xAI generation, Neon concurrency/migrations, Vercel deployment, browser E2E | Not run | Requires real credentials and deployed infrastructure. |

Do not add the focused 25-test run to the 198 script count as though they were one application suite. The 25 Imagine tests are utility-level checks, and there are no complete route-to-database-to-xAI integration tests in this evidence set.

## Findings that remain open

### P0 — release evidence is incomplete

A release must not be called production-ready until a clean environment passes `npm ci`, `npm test`, `npm run typecheck`, `npm run lint`, and `npm run build`, followed by staging tests using a separate xAI key and Neon database. Verify that secrets never enter browser bundles or responses.

### Resolved by this upgrade — output retention was not integrated

Before this upgrade, the app persisted only the ephemeral `video.url` from the video-generation response and did not request or save `video.file_output.file_id`.

**Implemented:** video generation requests now set `storage_options` with a 30-day TTL and no public URL. The completed poll response persists `video.file_output.file_id`. A same-origin route validates the visitor cookie and job ownership, then streams the private file content (including a valid single byte-range request) through the server. The xAI key and file ID are never exposed to the client. External object storage remains an option for longer retention.

### P1 — anonymous identity is not customer identity

The app intentionally has no account system. Signed cookies prevent trivial forgery, but a visitor can clear/change browser state and obtain another anonymous identity. The shared global clip/spend cap is the final backstop, not a billing/account boundary. Before opening the service broadly, add host WAF/bot controls and decide whether authenticated accounts and per-account quotas are required.

### Resolved by this upgrade — poll limit was fixed-window, not a rolling limiter

Polling now uses an atomic PostgreSQL token-bucket UPSERT shared across app instances. The global bucket has a one-request burst and refills at eight tokens/second; per-visitor and trusted-IP buckets further constrain individual clients. This avoids second-aligned fixed-window boundary spikes. It is still an application-side admission control, not a guarantee that xAI will never apply its own rate limiting.

### P1 — ambiguous paid submissions require manual reconciliation

Local idempotency prevents repeat submissions for the same visitor/key within the app database. It cannot guarantee provider-side idempotency when the xAI POST may have been accepted but its response is lost. The `submission_unknown` state is a safe hold, but the operational process is manual and needs a tested reconciliation tool/runbook before unattended commercial operation.

### P2 — no end-to-end regression evidence

Still open: add tests that exercise the actual route handlers with mocked upstream responses and a real temporary PostgreSQL-compatible database. Include parallel quota reservations, same-key retry races, provider 4xx/5xx/timeout cases, polling transitions, cookie ownership, byte-range download behavior, and restart/reload recovery. Add a browser test for upload → settings → cost approval → generation → playback/download → reload.

## Current xAI contract references

- Video generation is asynchronous: POST `/v1/videos/generations`, then poll GET `/v1/videos/{request_id}`.
- Image-to-video output follows the input image's aspect ratio; the current crop-before-submit approach is consistent with that behavior.
- Current Lite pricing is $0.01 per input image plus $0.02/sec (480p), $0.03/sec (720p), or $0.14/sec (1080p).
- Video generation supports persistent `storage_options`; private file content can be retrieved through the Files API.

See the linked official references in the accompanying README and production-readiness checklist.

## Honest release label

This package is a **hardened production candidate**. It is not a certified production release. The remaining blockers are concrete and testable; none should be hidden behind a “ready” badge.
