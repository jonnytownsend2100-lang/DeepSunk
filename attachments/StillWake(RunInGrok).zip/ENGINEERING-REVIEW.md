# Stillwake Studio — engineering review

## The roast

The earlier "Professional" zip was a better UI, not a production release. It described an app-wide cap as though it were an individual allowance, had no complete durable job ledger, and did not make paid generation retries safe. It was a prototype wearing a better typeface.

**Correction on authentication:** the workspace contract explicitly keeps account sign-in off unless the product asks for accounts or per-user data. This app is intentionally anonymous, so adding a fake login screen would not fix the real risk. The correct controls are signed visitor identity, ownership-bound job capabilities, abuse limits, and a hard shared spend ceiling.

## Engineering changes in this pass

### Identity and request boundary

- Added a cryptographically random, HMAC-signed anonymous visitor cookie (`HttpOnly`, `SameSite=Lax`, `Secure`/`__Host-` on HTTPS), with the expiry included in the authenticated cookie payload. HTTPS requests accept only the `__Host-` cookie name.
- Production fails closed unless `STILLWAKE_SESSION_SECRET` is configured with at least 32 bytes of entropy. Preview uses an ephemeral process secret only.
- Persisted only keyed visitor/IP digests. Raw cookie IDs and client IPs are not stored.
- Job tokens are expiring HMAC tokens bound to the visitor digest; polling additionally verifies row ownership in PostgreSQL.
- Generation and polling POSTs require JSON, a same-origin `Origin`, and reject `Sec-Fetch-Site: cross-site`. The polling capability token is sent in a bounded POST body rather than a query string.
- The API remains anonymous by product design, per the workspace rules (no accounts requested). It is not represented as account authentication.

### Spend and abuse controls

- Added atomic global daily clip and estimated-USD reservations.
- Added atomic visitor daily quotas.
- Added trusted-Vercel-IP hourly/daily request limits. The app requires both `VERCEL=1` and Vercel's `x-vercel-id` system header before trusting `x-forwarded-for`; see https://vercel.com/docs/headers/request-headers.
- Retained reservations when upstream outcome is ambiguous; only definitive upstream 4xx rejections release the clip/USD reservation, after the failed state is persisted.
- Added per-visitor idempotency keys backed by a unique database index and a fingerprint of the exact prompt/image/settings. A retry replays the existing job; reusing a key for different input is rejected. The frontend preserves the key after transport/5xx failures.
- Added server-side JPEG/PNG/WebP container and dimension checks to reject MIME spoofing, malformed headers, and oversized declared images before contacting xAI.
- If xAI accepts a job but the response stream or local request-ID persistence fails, the app returns/retains an unknown job rather than prompting a blind paid retry.
- Added bounded upstream response reads and transactional PostgreSQL token-bucket polling limits at visitor, trusted-IP, and app-wide levels. The app-wide bucket allows a one-request burst and refills at 8 requests/second, leaving headroom below xAI Lite's published 10 requests/second model limit.
- Added a private xAI Files API output path (30-day TTL), persisted server-side file IDs, and a same-origin visitor-owned download proxy. The proxy supports single byte ranges, applies a visitor download token bucket, validates provider content-range/type, and streams with a 300 MiB hard cap without buffering the whole MP4.
- Replaced the previous wall-clock polling buckets with transactionally reserved token buckets using database wall-clock time; rate-limit denial rolls back the other reservations in the same transaction.
- Added focused tests for continuous refill, SQL admission behavior, bounded stream behavior, byte-range validation, and idle-timeout cancellation.
- Persisted completed MP4 assets privately through xAI Files API for 30 days; a session-owned proxy streams byte ranges without exposing the provider key or generating public links.

### Durable job lifecycle

- Added transaction support to both the Neon and PGLite SQL adapters. Global spend, per-visitor allowance, trusted-IP counters, and the durable job insert now commit or roll back as one database transaction. A failed insert cannot strand a quota reservation.
- Abandoned `submitting` records are promoted to `submission_unknown` when polled, making the manual-reconciliation state durable instead of leaving ambiguous jobs stuck in an interim state.
- Expanded duration selection to the full documented 1–15 second range and corrected the remaining-budget calculation to use the true cheapest supported clip cost.

- Added `imagine_jobs` with owner digest, request ID, encrypted prompt, settings, estimate, status, errors, and timestamps.
- Job lifecycle is persisted before submission (`submitting`), then `pending`, `done`, `failed`, `expired`, or `submission_unknown`.
- Recent jobs are loaded from the server on page entry; pending work resumes polling after refresh.
- Job retention is cleaned up best-effort after 90 days; rate-limit and token-bucket rows are cleaned up after 2 days.

### API and UI correctness

- Preserved the xAI server-only key pattern and `grok-imagine-video-1.5-lite` model.
- Cropped the input image to the requested ratio. Current xAI image-to-video docs say the output matches the still image ratio; crop-first provides deterministic framing without geometric distortion.
- Separated per-visitor quota from the global estimated spend ceiling in status reporting; the UI now blocks a selection whose estimate exceeds the currently remaining shared spend budget.
- Reduced the Neon/node-postgres pool to two connections per warm serverless instance, with bounded connection/query timeouts and idle-client error logging.
- Extended polling to 15 minutes, resumed from persisted job records, and distinguished unknown submission outcomes from definite failures.

## Important limits that remain

- **Not deployment-certified:** no production xAI credential, Neon database, Vercel deployment, or real-browser session was available here. Do not call this "100% production verified" until the README test matrix is run in the target environment.
- **Media retention:** completed MP4 files are stored privately with xAI for 30 days and streamed through an owner-checked endpoint. This is not an indefinite archive; download clips or configure external object storage for longer retention.
- **Provider billing:** the $25/day ceiling reserves a published-rate estimate. It is an application spend guard, not a guarantee of the final provider invoice. Reconcile against xAI usage and add provider-side hard spend limits where available.
- **Network limits:** trusted IP throttles are only active on Vercel requests that carry both `x-vercel-id` and `x-forwarded-for`; Vercel documents that it overwrites `x-forwarded-for`. For other hosting, provide a trusted proxy integration.
- **No accounts:** visitors use an anonymous signed cookie. Clearing cookies creates a new visitor identity; network and global caps remain as additional defenses. This is a lightweight public-app control, not strong identity proof.
- **Ambiguous requests:** the app's idempotency key prevents duplicate local submissions for exact client retries, but xAI does not expose a provider idempotency key in the wired REST flow. If the xAI acceptance response is lost before its `request_id` is durably stored, the job is marked `submission_unknown`; operator review in the xAI console is still required.

## Required target-environment verification

```bash
npm ci
npm test
npm run typecheck
npm run lint
npm run build
```

Then perform live tests from a deployed URL: secure cookie issuance, origin rejection, concurrent quota reservations, xAI start/poll, reload recovery, missing-secret fail-closed behavior, Neon outage fail-closed behavior, and checking actual xAI billing against estimated reservations.

Focused tests: 26/26 Imagine utility/security/media tests pass; repository script suite: 198/198 pass. The complete `npm test` still exits non-zero because the current environment has not installed `@tanstack/react-start` and `jose` (35 other tests pass in that phase). No full production build, real xAI request, Neon concurrency run, or deployed browser test is claimed by this review.
