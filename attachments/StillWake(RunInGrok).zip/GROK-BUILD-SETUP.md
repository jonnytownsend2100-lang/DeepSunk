# Run Stillwake Studio in Grok Build

This is an application project for Grok Build, not a hosted service or a static mockup. Its generation buttons call the xAI Imagine Video REST API from server-only code.

## Runtime wiring

- `startup.sh` is the workspace restart entry point. Keep it and `scripts/with-app-env.mjs` intact; the app starts through `npm run dev` and binds to the preview's expected interface/port.
- `.grok/app-env.json` enables the deployment database. Grok Build preview uses the app's local PGLite fallback; deployed builds use the provisioned Neon/Postgres database.
- `XAI_API_KEY` must be present in the server environment. Grok Build supplies the platform xAI credential where enabled. The app checks for it and reports a missing-key state instead of exposing it to the browser.
- `STILLWAKE_SESSION_SECRET` must be set to at least 32 random characters in deployed environments. Preview uses a process-lifetime random secret; restarting preview invalidates its visitor cookie and in-progress local preview history.
- Never put either secret in `VITE_` variables, source files, or a committed `.env` file.

## Capabilities

1. **Text** — prompt-only video.
2. **Image** — animate one still as the opening frame.
3. **Reference** — guide a shot with up to 14 reference images and up to three preset voices.
4. **Director** — pin opening/closing frames, add up to four timed interior keyframes, and combine them with references and voices. For bounded app-builder transport, Director mode caps all image assets combined at 14; this is deliberately stricter than xAI's separate reference-image allowance.

Both Grok Imagine Video 1.5 and 1.5 Lite are available. The UI shows the current model-specific duration, resolution, audio and estimated-cost controls. Reference guidance, voice direction and Director shots with additional pins/references require full 1.5 and are capped at 720p. A Director draft with only one opening image behaves like ordinary image-to-video and can use Lite/1080p. Full 1.5 produces native 1080p for text/image jobs; Lite's 1080p output is upscaled from 720p.

## First-run verification

Use the service status panel in the studio. It reports whether the xAI key, session secret, and shared database are ready. Start with a short, low-resolution clip to validate the complete job lifecycle before trying longer/high-resolution outputs. Confirm that the result still plays after a refresh and that the download route remains owner-scoped.

The source package has automated contract/security tests, but a real xAI generation still requires the runtime credential and a live Grok Build environment. Do not treat local source tests as proof of a live paid API call.
