# Stillwake Studio — production operations runbook

This runbook is for the deployed, anonymous image-to-video service. The project intentionally has no account system. Treat every generation as a paid, public-facing operation against the owner's xAI account.

## Required production configuration

Provision these values in the hosting provider's encrypted server-side environment. Do not put any of them in a `VITE_` variable, source file, client bundle, or checked-in environment file.

| Setting | Requirement |
|---|---|
| `XAI_API_KEY` | Active xAI API key with Imagine video access. |
| `DATABASE_URL` | Neon PostgreSQL **pooled** connection string. Keep the DB in a supported/nearby region. |
| `STILLWAKE_SESSION_SECRET` | At least 32 random bytes; stable across all app instances and deploys. |

Generate a session secret with `openssl rand -base64 48`. Store it in the hosting provider's Production environment and any intentionally enabled Preview environment. Never paste it into a commit or browser-facing setting.

`.grok/app-env.json` must keep `deploy.database=true`. Vercel should provide `VERCEL=1`, `x-vercel-id`, and its overwritten `x-forwarded-for` header; the application refuses to trust arbitrary forwarded-IP headers on other hosts.

## Release procedure

1. Verify the target database has a recent backup / point-in-time recovery enabled.
2. Review new numbered SQL migrations. Never edit an already-applied migration; append the next migration number.
3. Deploy to a Preview environment with a separate database and a low-cost xAI key/budget where possible.
4. Run `npm ci`, `npm test`, `npm run typecheck`, `npm run lint`, and `npm run build` in CI. The build applies pending top-level migrations when `DATABASE_URL` is present.
5. Exercise the preview smoke matrix below before promoting.
6. Promote to Production, confirm migrations completed, and verify the service readiness state before enabling traffic.
7. Run one user-approved 6s/480p generation. Compare the app estimate to the xAI usage console.

## Budget and abuse controls

Current defaults live in `src/lib/imagine/limits.ts`:

- Preview: one render per visitor/day; $2.50 estimated reserved spend/day.
- Production: five renders per visitor/day; 50 total app jobs/day; $25 estimated reserved spend/day.
- Trusted Vercel IP generation limits: eight starts/hour and 15 starts/day.
- Polling: per-visitor and per-IP fixed-minute limits plus atomic token buckets (4-request app-wide burst, 8 requests/second refill; lower per-visitor and per-IP buckets).

These are application-level estimates and throttles, not a provider billing guarantee. Review xAI usage and configure provider-side account/org spending limits or alerts where available. Reduce `DAILY_SPEND_CAP_USD` and the clip budgets before public launch if the owner is not comfortable with the worst-case exposure. A cookie reset creates a new anonymous visitor; the shared app budget and trusted network limits are the backstops.

## Readiness and smoke matrix

The studio should only enable Generate when all three are true: the server key is present, the shared DB is available, and the visitor signing secret is configured.

Test these cases in a deployed preview:

- `/api/imagine/status` issues an HTTPS `__Host-` cookie with `Secure`, `HttpOnly`, `SameSite=Lax`, and `Path=/`.
- A POST without `Origin`, with a foreign `Origin`, or with `Sec-Fetch-Site: cross-site` is rejected.
- Oversized/chunked JSON, invalid base64, MIME spoofing, and oversized image dimensions are rejected before contacting xAI.
- Clearing the visitor cookie produces a new anonymous visitor, but the shared daily app cap still applies.
- Concurrent starts cannot exceed the global and visitor quota UPSERT limits.
- Repeating the same idempotency key and exact payload returns the original job; reusing that key with changed input returns HTTP 409.
- Browser refresh restores recent jobs; a pending job resumes polling; a foreign visitor cannot poll the job token.
- Missing `XAI_API_KEY`, missing `STILLWAKE_SESSION_SECRET`, missing migrations, and Neon outages fail closed before a paid xAI submission.
- xAI `done`, `failed`, and `expired` states persist and render as expected.
- The browser bundle, rendered HTML, logs, and API payloads contain no xAI key or raw visitor cookie ID.

## Incident handling

### A job is `submission_unknown`

Do not ask the visitor to click Generate again. This state means the upstream POST may have been accepted but the app could not durably learn/record its xAI request ID. Check the xAI usage/request history for the approximate UTC time and customer action. After reconciliation, update the corresponding job and reservation through a reviewed operator procedure. Do not manually decrement reserved spend unless the provider confirms no billable generation was accepted.

### The shared budget is exhausted unexpectedly

Stop new paid traffic by lowering the caps or temporarily removing `XAI_API_KEY`. Check the `imagine_jobs` rows, `imagine_daily_budget`, and xAI usage console. Preserve ambiguous reservations until reviewed. Investigate unusual visitor/IP churn and enable host firewall/WAF or bot protection before reopening.

### Neon is unavailable or migrations failed

Generation is intentionally fail-closed. Check deployment logs for `[db]` and `[imagine]` prefixes, verify `DATABASE_URL` points to the Neon pooled endpoint, and inspect `_migrations`. Restore DB service or fix the failed migration; do not bypass the ledger with an in-memory fallback in Production.

### Rotate `STILLWAKE_SESSION_SECRET`

This invalidates existing visitor cookies and job tokens. It also changes the current prompt-encryption derivation, so previously stored prompts will no longer decrypt. Treat rotation as a planned maintenance operation: first export/reencrypt any prompt history that must be retained, announce visitor-session invalidation, then rotate all app instances together. Do not rotate only one instance in a multi-instance deployment.

## Known production limits (do not hide these)

- Completed MP4s are stored privately in the xAI Files API with a 30-day TTL (`storage_options.filename` + `expires_after: 2592000`). The app persists `file_output.file_id` and streams downloads through `/api/imagine/download/$jobId` only after checking the signed visitor cookie and row ownership; the proxy validates byte ranges, caps streams at 300 MiB, and aborts stalled streams after a per-chunk idle timeout. The app does not create public URLs. Users must download clips before the 30-day expiry; bring-your-own object storage is still an option for longer retention.
- xAI provider-side idempotency is not used in this REST integration. Local idempotency protects browser retries, but a lost provider response can still require manual reconciliation.
- The app-wide poll limit uses an atomic PostgreSQL token bucket with a one-request burst and 8-token/second refill. This controls application-originated poll calls across instances; xAI rate limits remain independently enforced by the provider.
- The spend guard reserves published-rate estimates, not measured final provider charges. Reconcile daily with the provider console.
- Anonymous cookie identity is not strong user identity. Use host WAF/bot protection and account authentication if this becomes a public multi-tenant product.
- No production deployment, real xAI billing test, or real Neon concurrency run is certified by the local test results alone.
