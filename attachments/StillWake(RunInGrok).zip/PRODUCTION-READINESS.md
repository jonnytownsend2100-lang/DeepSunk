# Stillwake Studio — release readiness

**Release classification: production-oriented candidate; not production-certified.**

This package hardens the generation path, but a source checkout cannot establish production readiness by itself. The checks below distinguish what was verified in this environment from what needs real infrastructure and provider credentials.

## Verified in this workspace

- 198/198 standalone repository script tests pass.
- 26/26 focused Stillwake tests pass, covering pricing, image validation, visitor sessions, prompt encryption, job tokens, idempotency, token-bucket behavior, bounded streaming, byte-range validation, and stalled-stream idle timeouts.
- API route handlers require same-origin JSON POSTs, bound request sizes, and reject cross-site fetches.
- Paid generation fails closed unless the server has an xAI key, stable 32+ byte session secret, and shared PostgreSQL storage.
- Spend/clip reservations, per-visitor quotas, IP limits where trusted, and durable job creation are committed in one SQL transaction.
- Visitor capability tokens are HMAC-signed, expiring, and owner-bound.
- Prompt history is encrypted with AES-256-GCM before persistence.
- Image data URIs are checked for supported media signatures and dimensions before upstream submission.
- Local retry keys and request fingerprints prevent the browser from creating duplicate local paid jobs on the same request key.
- xAI request/response handling is bounded and ambiguous outcomes are held for manual reconciliation rather than blindly retried.

## Not verified here

- A clean `npm ci`, TypeScript typecheck, ESLint run, production Vite build, and deployed browser smoke test. `npm ci --offline` failed because the local npm cache lacks packages, and online install could not reach the registry. `npm test` ran 198/198 repository-script tests successfully, then exited non-zero because two test files could not import the missing `@tanstack/react-start` and `jose` dependencies; the other 35 tests in that phase passed. The separately targeted Stillwake suite passed 26/26.
- xAI live generation, live provider billing, and the response/poll lifecycle with real credentials.
- Neon transaction behavior under concurrent load and migration execution in the target database.
- Vercel secure cookie behavior, trusted-IP rate limits, production routing, and log redaction in the actual deployment.
- Private xAI Files API persistence is implemented with 30-day TTL, and the owner-checked streaming download route is implemented. A real xAI credentials/host integration test remains mandatory.

## Mandatory release gate

Run these commands after extracting the ZIP in a clean environment with network access:

```bash
npm ci
npm run test:scripts
npm run test:imagine
npm test
npm run typecheck
npm run lint
npm run build
npm run dev
```

Then deploy to a staging project with a separate xAI key and Neon database. Verify:

1. `XAI_API_KEY`, `DATABASE_URL`, and `STILLWAKE_SESSION_SECRET` are server-only; none appear in client bundles, source maps, page HTML, or API responses.
2. HTTPS issues a `__Host-` + `Secure` + `HttpOnly` + `SameSite=Lax` cookie; HTTP local preview uses the non-`__Host-` development cookie.
3. Cross-origin POSTs, missing `Origin`, invalid JSON, invalid MIME signatures, giant bodies, and missing visitor sessions fail before xAI is contacted.
4. Concurrent requests cannot exceed global clip/spend reservations, visitor quotas, or trusted-IP caps.
5. Identical idempotency-key retries replay the same job; changed payloads with a reused key return conflict.
6. The xAI request ID and each terminal/pending state persist across a server restart and page reload.
7. Provider 4xx rejections release reservation exactly once; ambiguous network/5xx responses retain their reservations for manual reconciliation.
8. xAI rates and actual billed amounts match the current pricing page and the estimates shown by the UI.
9. Confirm a completed render stores `file_output.file_id`; test authenticated playback, byte-range seeking, foreign visitor denial, and the 30-day expiry behavior. Use object storage for longer retention.
10. Database outage, missing secret, and missing provider key fail closed without a generation call.

## Operational constraints

- Default live cap: 50 generations and $25 estimated reserved spend per UTC day, 5 generations per anonymous visitor/day, plus trusted-Vercel-IP request controls.
- The spend ledger reserves estimates using current published model rates; it is not a provider invoice guarantee. Set provider-side billing limits and reconcile usage.
- Anonymous browser cookies are not strong identity. Add account auth and a WAF/bot-management layer before opening high-value generation to an unrestricted public audience.
- Unknown submission outcomes require an operator to compare timestamps/request history against the xAI console before releasing any reservation.
- Visitor cookie secret rotation invalidates sessions and prompt decryption. Coordinate rotation across all instances and plan for historical prompt data first.
- The current storage plan is private xAI Files API with 30-day retention, not an indefinite archive. For long-term customer libraries, configure independent object storage plus lifecycle deletion and restore testing.

## Current xAI documentation

- [Grok Imagine Video 1.5 Lite model and pricing](https://docs.x.ai/developers/models/grok-imagine-video-1.5-lite)
- [Video generation capability and image-to-video behavior](https://docs.x.ai/developers/model-capabilities/video/generation)
- [Video REST API reference](https://docs.x.ai/developers/rest-api-reference/inference/videos)
- [Image-to-video input formats](https://docs.x.ai/developers/model-capabilities/video/image-to-video)
- [Persisting generated video output with `storage_options`](https://docs.x.ai/developers/model-capabilities/imagine/files/outputs)
- [Retrieving private Files API content](https://docs.x.ai/developers/files/managing-files)
