# Stillwake Studio

A cinematic creative workstation for xAI Grok Imagine Video. It supports text-to-video, image-to-video, reference-guided generation, and Director mode with pinned frames and timed keyframes. It intentionally uses signed anonymous visitor sessions rather than account sign-in; paid generation is guarded on the server, not by client UI state.

## Creative workflows

- **Text to video:** generate from a creative brief without uploading a source image.
- **Image to video:** use one optimized still as the opening frame.
- **Reference guided:** use up to 14 reference images and up to three preset voice references.
- **Director mode:** pin an opening frame, closing frame, and up to four middle keyframes; combine those with visual references and speaker voices. The application applies a stricter 14-image combined transport cap so a maximum request remains inside its bounded JSON upload envelope.
- **Model choice:** `grok-imagine-video-1.5` for references, pinned frames, voice direction and native 1080p text/image generation; `grok-imagine-video-1.5-lite` for lower-cost text/image generation. Lite 1080p is upscaled from 720p. Reference workflows are capped at 720p.
- **Shot controls:** 1–15 seconds, nine supported aspect ratios, 480p/720p/1080p where supported, optional generated audio, four prompt direction presets, and live estimated cost with mandatory per-render approval.
- **Speaker direction:** assign up to three preset xAI voices and place `<AUDIO_0>`, `<AUDIO_1>`, and `<AUDIO_2>` tags in the prompt. Preset voices require generated audio.
- Images are decoded and optimized in the browser, then cropped to the selected output aspect ratio before submission. Uploaded originals are not persisted by Stillwake.

## Model pricing estimate

The UI estimate uses the currently published xAI video-output rate plus $0.01 per image input. It does not promise a final invoice amount; provider usage/billing remains authoritative. Current values encoded in `src/lib/imagine/limits.ts`:

| Model | 480p | 720p | 1080p |
|---|---:|---:|---:|
| Grok Imagine Video 1.5 Lite | $0.02/sec | $0.03/sec | $0.14/sec (upscaled) |
| Grok Imagine Video 1.5 | $0.08/sec | $0.14/sec | $0.25/sec |

Every submitted image asset adds $0.01. The app reserves its estimate before submitting to xAI. Confirm prices against the [xAI pricing page](https://docs.x.ai/developers/pricing) before changing public limits or displaying a new rate.

## Grok API payload contract

Generation uses `POST https://api.x.ai/v1/videos/generations` and asynchronous status polling. `src/lib/imagine/request-contract.ts` is the shared server-side validator and payload builder. It validates model/mode combinations, dimensions, media count, exact image headers, voice IDs, keyframe timestamps on the ⅓-second grid, and spend confirmation. The tests exercise the payload shapes independently from the UI.

## Required runtime configuration

Start with [`.env.example`](./.env.example) for variable names; never commit real values. The deployed app requires:

| Variable | Purpose |
|---|---|
| `XAI_API_KEY` | Server-only xAI credential. Never expose it as a `VITE_` variable. |
| `DATABASE_URL` | Neon/PostgreSQL connection string for shared quotas and durable job state. |
| `STILLWAKE_SESSION_SECRET` | At least 32 random characters; signs visitor cookies/job tokens and derives the prompt-encryption key. Keep stable across deploys. |

Generate a secret with `openssl rand -base64 48`, set it in the deployment environment, and never commit it. Rotating it invalidates visitor cookies/job tokens and makes previously encrypted prompts unreadable; plan rotation deliberately.

The Grok workspace preview uses a process-local random secret and PGLite. That fallback is for preview only and resets on process restart. The deployed environment must set the secret and use Neon; generation fails closed if either is missing. The app keeps `VITE_AUTH_ENABLED=false` because it has no user accounts. Anonymous usage is protected by signed sessions, server-side per-visitor quotas, Vercel IP limits when trusted headers are present, same-origin validation, and a shared daily spend reservation. A public deployment still needs Vercel Firewall/WAF policy and abuse monitoring.

## Spend protection

- Workspace preview: up to five confirmed renders per UTC day, subject to a $2.50 estimated-reservation ceiling. The dollar ceiling remains the controlling limit for longer or higher-resolution clips.
- Deployed app: five renders per signed visitor per UTC day, eight attempts per trusted IP per hour, fifteen per trusted IP per UTC day, 50 application jobs and $25 estimated reserved spend per UTC day.
- Quotas, global spend reservation, rate counters, and durable job creation commit transactionally before calling xAI.
- Definitive upstream 4xx rejections release reservations. Network errors, upstream 5xx responses, and malformed success responses are marked `submission_unknown`; the reservation stays held to prevent accidental duplicate paid generations. These states need operator reconciliation against xAI request history.
- Polling/download admission uses PostgreSQL token buckets shared between app instances. The global poll bucket has a one-request burst and an eight-token-per-second refill.

The shared dollar ceiling guards the application's published-rate estimate, not xAI's final invoice. Provider billing is authoritative.

## Private output retention

Completed generations request private xAI Files API storage with a 30-day expiry. Stillwake stores `file_output.file_id` server-side and returns only an owner-checked same-origin `/api/imagine/download/$jobId` route. That route verifies the signed visitor session, enforces a download token bucket, and streams the MP4 from the authenticated Files API with a bounded byte limit, idle timeout, and single byte-range support. The browser never receives the xAI API key or raw file ID. Download clips before expiry. S3-compatible storage remains an option for longer retention, but is not mandatory for this xAI-backed workflow.

## Database and migrations

`deploy.database` is enabled in `.grok/app-env.json`. Top-level migrations are applied in preview and deployment. Add schema changes as new numbered migrations; do not edit migrations already applied to a live database.

- `imagine_daily_budget`: shared daily job count and estimated USD reservations.
- `imagine_visitor_daily_usage`: daily count per signed visitor.
- `imagine_rate_limits`: short-window IP and visitor throttles.
- `imagine_token_buckets`: shared continuous-refill admission limits.
- `imagine_jobs`: lifecycle, encrypted prompt, model/mode, image count, settings, request ID, idempotency fingerprint, estimated cost and private xAI file ID.
- Migration 0006 adds generation mode and billable image count to job history.

## API contract

- `GET /api/imagine/status`: creates/reads the signed visitor cookie and returns readiness, visitor/global usage, and recent owner-scoped jobs.
- `POST /api/imagine/start`: same-origin JSON only; bounded request body; validates selected model and workflow; atomically reserves spend and quotas; inserts a durable job; sends the documented mode-specific Grok payload to xAI.
- `POST /api/imagine/poll` with `{ "token": "…" }`: validates the visitor-bound job token, checks ownership, polls xAI and updates durable state.
- `GET /api/imagine/download/$jobId`: validates visitor session/database ownership and streams a privately stored MP4 without exposing provider credentials or file IDs.

All API responses are `private, no-store`; the xAI API key and raw visitor cookie ID never enter client-visible payloads.

## Local development and checks

```bash
npm ci
npm run test:scripts
npm run test:imagine
npm test
npm run typecheck
npm run lint
npm run build
npm run dev
```

Run preview using `npm run dev` on `0.0.0.0:8080` in the Grok app-builder workspace. Keep the existing `startup.sh`, `vite.config.ts`, router, and `.grok/app-env.json` intact. Do not commit a `.env` file or any credentials.

Before publishing, run the complete build and typecheck in the actual Grok container, then use a real API key for a low-cost 480p test in each workflow. Verify private file retrieval after refresh, first/last frame behaviour, keyframe timing, reference and voice mapping, output expiry, database concurrency, and the invoice against the displayed estimate. These are release gates, not claims that they have already been tested from this archive-building environment.
