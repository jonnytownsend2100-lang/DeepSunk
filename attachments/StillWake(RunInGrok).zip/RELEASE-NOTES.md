# Stillwake Studio — Cinematic Grok Imagine Edition

## What this release contains

This is a Grok Build application project for a cinematic AI video workstation. It is not a hosted service and it has not been deployed into the user's private Grok Build workspace from this packaging environment.

### Creative workstation

- Editorial dark studio design with responsive desktop and mobile layouts.
- Four workflows: text-to-video, image-to-video, reference-guided, and Director.
- Grok Imagine Video 1.5 and 1.5 Lite model selection.
- 1–15 second clips, supported aspect ratios, model-aware resolution controls, and optional generated audio.
- Image optimization/cropping, visual references, opening/closing frame pins, up to four interior keyframes, and up to three preset speaker voices.
- Prompt tags for image and speaker references are maintained as media is reordered or removed.
- Model-aware cost estimate, explicit per-render approval, visitor limits, and shared spend ceilings.

### Server and media handling

- Real server-side calls to the xAI Imagine Video REST API. `XAI_API_KEY` is never placed in browser code.
- Server-side validation of workflow/model combinations, image signatures and dimensions, reference counts, voice IDs, and keyframe timing.
- Signed anonymous visitor sessions, owner-bound job tokens, idempotent generation intent, encrypted prompt storage, and database-backed spend reservations.
- Shared PostgreSQL token buckets for polling and download admission.
- Private xAI Files API output storage with a 30-day expiry, server-side file IDs, and an owner-checked same-origin streaming download proxy.
- Bounded MP4 streaming, single byte-range support, an overall byte cap, response-header timeout, and per-chunk idle timeout.

## Verified in the packaging environment

- `npm run test:scripts`: 198 tests passed.
- `npm run test:imagine`: 37 tests passed.
- Grok Build brand check: passed with zero warnings.
- TypeScript syntax transpilation checks: passed for the modified Studio UI, root/index routes, Imagine API routes, request contract, limits, and server implementation.
- Secret scan: no committed `.env`, private-key file, or matching xAI/API key pattern found in the packaged source tree.
- ZIP integrity: checked with `unzip -t`.

## Not verified here — do not infer otherwise

- Full dependency-backed `npm test`, `npm run typecheck`, lint, or production `npm run build`.
- Live Grok Build preview or deployment in the user's account.
- Live xAI API generation or real provider billing.
- Real Neon concurrency, deployment secrets, cross-instance behavior, or browser end-to-end testing.

The dependency installation was not available in this environment, so Vite/TypeScript application dependencies were absent. Syntax transpilation is not a substitute for a complete typecheck or build. A live API test also requires the platform-injected `XAI_API_KEY` and an actual Grok Build runtime.

## Import and first-run

1. Import/extract the project into a Grok Build workspace.
2. Keep `startup.sh`, `vite.config.ts`, `.grok/app-env.json`, and the `.grok/skills/` references intact.
3. Confirm the Grok Build runtime injects server-only `XAI_API_KEY` and provisions the configured PostgreSQL database for deployment.
4. Set `STILLWAKE_SESSION_SECRET` to at least 32 random characters in deployed environments. Never put it in a `VITE_` variable or committed `.env` file.
5. Start the preview using the workspace's normal startup action. The project startup entry point runs `npm run dev` on `0.0.0.0:8080`.
6. Check the studio's service status, then run a short 480p generation and verify polling, refresh persistence, private playback/download, and billing before wider use.

See [GROK-BUILD-SETUP.md](./GROK-BUILD-SETUP.md) and [README.md](./README.md) for the complete configuration, security, limits, API, migration, and test instructions.
