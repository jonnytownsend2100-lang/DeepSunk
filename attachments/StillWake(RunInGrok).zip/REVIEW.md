# Stillwake Studio — engineering review

## The roast

The earlier "Professional" zip was a better UI, not a production release. It described an app-wide cap as though it were an individual allowance, had no complete durable job ledger, and did not make paid generation retries safe. It was a prototype wearing a better typeface.

**Correction on authentication:** the workspace contract explicitly keeps account sign-in off unless the product asks for accounts or per-user data. This app is intentionally anonymous, so adding a fake login screen would not fix the real risk. The correct controls are signed visitor identity, ownership-bound job capabilities, abuse limits, and a hard shared spend ceiling.

## Engineering changes in this pass

### Identity and request boundary

- Added a cryptographically random, HMAC-signed anonymous visitor cookie (`HttpOnly`, `SameSite=Lax`, `Secure`/`__Host-` on HTTPS), with the expiry included in the authenticated cookie payload. HTTPS requests accept only the `__Host-` cookie name.
- Production fails closed unless `STILLWAKE_SESSION_SECRET` is configured with at least 32 bytes of entropy. Preview uses an ephemeral process secret only.
- Persisted only keyed visitor/IP digests. Raw cookie IDs and client IPs are not stored.
- Job tokens are expiring HMAC tokens bound to the visitor digest; polling additionally verifies row ownership in PostgreSQL.
- Generation and polling POSTs require JSON, a same-origin `Origin`, and reject `Sec-Fetch-Site: cross-site`. The polling capability token is sent in a bounded POST body rather than a query string.
- The API remains anonymous by product design, per the workspace rules (no accounts requested). It is not represented as account authentication.

### Spend and abuse controls

- Added atomic global daily clip and estimated-USD reservations.
- Added atomic visitor daily quotas.
- Added trusted-Vercel-IP hourly/daily request limits. The app requires both `VERCEL=1` and Vercel's `x-vercel-id` system header before trusting `x-forwarded-for`; see https://vercel.com/docs/headers/request-headers.
- Retained reservations when upstream outcome is ambiguous; only definitive upstream 4xx rejections release the clip/USD reservation, after the failed state is persisted.
- Added per-visitor idempotency keys backed by a unique database index and a fingerprint of the exact prompt/image/settings. A retry replays the existing job; reusing a key for different input is rejected. The frontend preserves the key after transport/5xx failures.
- Added server-side JPEG/PNG/WebP container and dimension checks to reject MIME spoofing, malformed headers, and oversized declared images before contacting xAI.
- If xAI accepts a job but the response stream or local request-ID persistence fails, the app returns/retains an unknown job rather than prompting a blind paid retry.
- Added bounded upstream response reads and transactional PostgreSQL token-bucket polling limits at visitor, trusted-IP, and app-wide levels. The global bucket has a one-call burst and 8 tokens/second refill, leaving headroom below xAI Lite's published limit.
- Added private xAI Files API MP4 output with a 30-day TTL and a session-owned same-origin streaming proxy; it supports one byte range and enforces a 300 MiB streaming cap.
- Added a visitor-scoped download token bucket and utility tests for stream overflow, range syntax, and continuous token refill.

### Durable job lifecycle

- Added transaction support to both the Neon and PGLite SQL adapters. Global spend, per-visitor allowance, trusted-IP counters, and the durable job insert now commit or roll back as one database transaction. A failed insert cannot strand a quota reservation.
- Abandoned `submitting` records are promoted to `submission_unknown` when polled, making the manual-reconciliation state durable instead of leaving ambiguous jobs stuck in an interim state.
- Expanded duration selection to the full documented 1–15 second range and corrected the remaining-budget calculation to use the true cheapest supported clip cost.

- Added `imagine_jobs` with owner digest, request ID, encrypted prompt, settings, estimate, status, errors, and timestamps.
- Job lifecycle is persisted before submission (`submitting`), then `pending`, `done`, `failed`, `expired`, or `submission_unknown`.
- Recent jobs are loaded from the server on page entry; pending work resumes polling after refresh.
- Job and throttle retention is cleaned up best-effort (90 days for jobs/visitor counters; 2 days for rate-limit windows).

### API and UI correctness

- Preserved the xAI server-only key pattern and `grok-imagine-video-1.5-lite` model.
- Cropped the input image to the requested ratio. Current xAI image-to-video docs say the output matches the still image ratio; crop-first provides deterministic framing without geometric distortion.
- Separated per-visitor quota from the global estimated spend ceiling in status reporting; the UI now blocks a selection whose estimate exceeds the currently remaining shared spend budget.
- Reduced the Neon/node-postgres pool to two connections per warm serverless instance, with bounded connection/query timeouts and idle-client error logging.
- Extended polling to 15 minutes, resumed from persisted job records, and distinguished unknown submission outcomes from definite failures.

## Important limits that remain

- **Not deployment-certified:** no production xAI credential, Neon database, Vercel deployment, or real-browser session was available here. Do not call this "100% production verified" until the README test matrix is run in the target environment.
- **Video retention:** new renders request private xAI Files API storage with a 30-day TTL. The app stores file IDs server-side and streams MP4s through an owner-checked same-origin endpoint. This is not indefinite retention; use independent object storage for long-term libraries.
- **Provider billing:** the $25/day ceiling reserves a published-rate estimate. It is an application spend guard, not a guarantee of the final provider invoice. Reconcile against xAI usage and add provider-side hard spend limits where available.
- **Network limits:** trusted IP throttles are only active on Vercel requests that carry both `x-vercel-id` and `x-forwarded-for`; Vercel documents that it overwrites `x-forwarded-for`. For other hosting, provide a trusted proxy integration.
- **No accounts:** visitors use an anonymous signed cookie. Clearing cookies creates a new visitor identity; network and global caps remain as additional defenses. This is a lightweight public-app control, not strong identity proof.
- **Ambiguous requests:** the app's idempotency key prevents duplicate local submissions for exact client retries, but xAI does not expose a provider idempotency key in the wired REST flow. If the xAI acceptance response is lost before its `request_id` is durably stored, the job is marked `submission_unknown`; operator review in the xAI console is still required.

## Required target-environment verification

```bash
npm ci
npm test
npm run typecheck
npm run lint
npm run build
```

Then perform live tests from a deployed URL: secure cookie issuance, origin rejection, concurrent quota reservations, xAI start/poll, reload recovery, missing-secret fail-closed behavior, Neon outage fail-closed behavior, and checking actual xAI billing against estimated reservations.

198/198 repository script tests and 26/26 focused Imagine tests pass. The full npm test run still fails to load two dependency-bound test files because `@tanstack/react-start` and `jose` are missing. No production build, real xAI request, Neon concurrency run, or deployed browser test is claimed by this review.
