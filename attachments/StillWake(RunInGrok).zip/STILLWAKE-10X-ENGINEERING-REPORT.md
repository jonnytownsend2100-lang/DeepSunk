# Stillwake Studio — engineering upgrade report

**Build date:** 2026-11-09  
**Release label:** hardened engineering candidate; not production-certified  
**Important:** “10x” is the requested upgrade target, not a measured performance multiplier. No benchmark was run that would justify a literal 10× claim.

## What materially changed in this pass

### 1. Private generated-video retention

- Every new video-generation request asks xAI to retain the completed MP4 privately through `storage_options` with a 30-day TTL.
- The request does not set `public_url`; the application does not intentionally create a public file URL.
- Completed `video.file_output.file_id` values are persisted in the job ledger, never sent to the browser.
- A new same-origin download endpoint requires the signed visitor cookie and verifies that the job row belongs to that visitor before retrieving the file from xAI Files API.
- Existing legacy jobs with a recorded HTTPS video URL retain a fallback path.

### 2. Bounded, resumable video delivery

- The proxy streams the response rather than buffering the entire MP4 in memory.
- The stream has a 300 MiB hard cap, including when the provider omits `Content-Length`.
- Single byte-range requests are validated and forwarded to support seeking; malformed/multipart ranges are not forwarded.
- Provider content type and `206 Content-Range` are validated before returning media bytes.
- The 15-second upstream-header timeout is cleared as soon as headers arrive; long active downloads are not cut off by a total 60-second deadline.
- Each stream read has a 30-second idle timeout. A stalled stream is canceled instead of hanging indefinitely.
- Downloads have a visitor-scoped database token bucket (120-token burst, 2-token/second refill).

### 3. Distributed rate admission

- Replaced second-aligned fixed polling buckets with atomic PostgreSQL token-bucket UPSERTs using database wall-clock time.
- Poll reservations for global, visitor, and trusted-IP buckets occur in one SQL transaction. If any bucket denies the request, the other reservations roll back too.
- Global poll configuration is a one-request burst with an 8-token/second refill, leaving headroom below xAI Lite's published 10 requests/second model limit.
- Visitor and trusted-IP buckets are more restrictive; existing per-minute counters remain as additional limits.
- Old bucket rows are removed by the existing best-effort retention sweep.

### 4. UI and operational corrections

- Download action now stays same-origin and uses the browser's `download` attribute instead of opening another tab.
- Poll retry behavior retains exponential backoff with jitter after network failures.
- User-facing messages describe private 30-day xAI storage, not temporary direct links or indefinite archives.
- README, audit addendum, production checklist, engineering review, and operations runbook were reconciled with the shipped code.
- Migration `0005_imagine_private_files_and_token_buckets.sql` adds the private file ID and shared bucket table.

## Verification performed

| Check | Result | Scope |
|---|---:|---|
| Repository script tests | **198 / 198 passed** | Workspace scripts, migration plan, tooling checks; not 198 video E2E tests. |
| Focused Stillwake tests | **26 / 26 passed** | Pricing, image validation, visitor identity, prompt/job-token crypto, idempotency fingerprints, token buckets, bounded media streams, range validation, idle timeout. |
| TypeScript check for new utility modules | **Passed** | Strict `tsc --noEmit` on `token-bucket.server.ts` and `media-stream.server.ts`; not a whole-app typecheck. |
| Syntax parse of changed server modules | **Passed** | Node TypeScript strip/check for the download route, video service, token bucket, and media-stream utility. |
| `npm test` | **Not clean** | Script phase 198/198 passed. Broader phase: 36 tests passed; 2 test files could not load because `@tanstack/react-start` and `jose` were not installed. |
| Dependency install | **Blocked** | Online npm install could not reach the registry; offline install failed `ENOTCACHED` because the package cache lacks required artifacts. |
| Full app typecheck/lint/build | **Not verified** | Requires a complete dependency installation. |
| Live xAI / Neon / browser E2E | **Not run** | Requires real credentials and deployed infrastructure. |
| ZIP CRC/integrity | **Checked at packaging** | Confirms archive readability, not runtime correctness. |

## Remaining production gates

1. Run `npm ci`, `npm test`, `npm run typecheck`, `npm run lint`, and `npm run build` in a network-enabled clean environment.
2. Apply migration 0005 to a staging Neon database and test concurrent quota/token-bucket transactions against real PostgreSQL.
3. With a separate xAI staging key, verify generation submission, `file_output.file_id`, private retrieval, range seeking, visitor ownership denial, 30-day expiry, and actual billing.
4. Test upload → approve estimate → generate → poll/resume after refresh → playback → download in supported browsers.
5. Test missing secrets, provider timeout/5xx, ambiguous submissions, provider 404 after file expiry, database outage, and WAF/rate-limit behavior.
6. Add an operator reconciliation workflow for `submission_unknown`; local idempotency cannot make an upstream xAI POST idempotent when the provider accepts it but the response is lost.
7. Add external object storage if renders must remain available beyond xAI's 30-day private-file expiry.

## Runtime limits worth knowing

- New private files expire after 30 days. Download user work before expiry or configure independent object storage.
- The spend ledger reserves published-rate estimates; reconcile against actual xAI billing.
- Visitor cookies are pseudonymous, not strong customer identity. Anonymous users can clear browser state; global spend and trusted network limits remain backstops. Add accounts/WAF controls before high-value public scale.
- The app's rate limits control requests made by this application, not all usage against the xAI account. Keep provider-side alerts/limits enabled where available.
